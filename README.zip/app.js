/* =====================================================
   TripSplit - Local MVP
   Bottom Navigation + Expenses + Members + Balances
   Supabase can replace the storage adapter later.
===================================================== */

const STORAGE_KEY = 'tripsplit_trips_v2';
const CURRENT_KEY = 'tripsplit_current_v2';

let state = {
    trips: {},
    currentId: null
};

const $ = id => document.getElementById(id);

const money = n =>
    '₹' + Number(n || 0).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

const uid = () =>
    Date.now().toString(36) +
    Math.random().toString(36).slice(2, 8);

function esc(s) {
    const d = document.createElement('div');
    d.textContent = s ?? '';
    return d.innerHTML;
}


/* =====================================================
   STORAGE
===================================================== */

function load() {

    try {

        state.trips = JSON.parse(
            localStorage.getItem(STORAGE_KEY) || '{}'
        );

        state.currentId =
            localStorage.getItem(CURRENT_KEY) || null;

    } catch {

        state = {
            trips: {},
            currentId: null
        };

    }

}


function save() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(state.trips)
    );

    if (state.currentId) {

        localStorage.setItem(
            CURRENT_KEY,
            state.currentId
        );

    }

}


function current() {

    return state.currentId
        ? state.trips[state.currentId]
        : null;

}


/* =====================================================
   TRIP CODE
===================================================== */

function code() {

    const chars =
        'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    let x = '';

    do {

        x = '';

        for (let i = 0; i < 6; i++) {

            x += chars[
                Math.floor(
                    Math.random() * chars.length
                )
            ];

        }

    } while (
        Object.values(state.trips)
            .some(t => t.code === x)
    );

    return x;

}


/* =====================================================
   VIEW NAVIGATION
===================================================== */

function show(view) {

    document
        .querySelectorAll('.view')
        .forEach(v => v.classList.remove('active'));

    const target = $(view + 'View');

    if (target) {

        target.classList.add('active');

    }

    $('backBtn')?.classList.toggle(
        'hidden',
        view === 'home'
    );


    const bottomNav = $('bottomNav');

    if (bottomNav) {

        if (view === 'trip') {

            bottomNav.classList.add('show');

            openTab('overview');

        } else {

            bottomNav.classList.remove('show');

        }

    }


    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });

}


/* =====================================================
   BOTTOM TAB NAVIGATION
===================================================== */

function openTab(tab) {

    document
        .querySelectorAll('.tab-content')
        .forEach(x => x.classList.remove('active'));


    document
        .querySelectorAll('.nav-item')
        .forEach(x => x.classList.remove('active'));


    const tabId =
        'tab' +
        tab.charAt(0).toUpperCase() +
        tab.slice(1);

    const content = $(tabId);

    if (content) {

        content.classList.add('active');

    }


    const nav =
        document.querySelector(
            `.nav-item[data-tab="${tab}"]`
        );

    if (nav) {

        nav.classList.add('active');

    }


    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });

}


/* =====================================================
   TOAST
===================================================== */

function toast(msg) {

    const t = $('toast');

    if (!t) return;

    t.textContent = msg;

    t.classList.add('show');

    clearTimeout(window._toast);

    window._toast = setTimeout(() => {

        t.classList.remove('show');

    }, 2300);

}


/* =====================================================
   MODAL
===================================================== */

function openModal(title, sub, html) {

    $('modalTitle').textContent = title;

    $('modalSubtitle').textContent = sub;

    $('modalBody').innerHTML = html;

    $('modal').classList.add('show');

    $('modal').setAttribute(
        'aria-hidden',
        'false'
    );

}


function closeModal() {

    $('modal').classList.remove('show');

    $('modal').setAttribute(
        'aria-hidden',
        'true'
    );

}


/* =====================================================
   CREATE TRIP
===================================================== */

function createTrip() {

    const name =
        $('tripName').value.trim();

    const creator =
        $('creatorName').value.trim();


    if (!name) {

        return toast(
            'Enter a trip name.'
        );

    }


    if (!creator) {

        return toast(
            'Enter your name.'
        );

    }


    const id = uid();


    const trip = {

        id,

        name,

        code: code(),

        members: [

            {
                id: uid(),
                name: creator
            }

        ],

        expenses: [],

        createdAt:
            new Date().toISOString()

    };


    state.trips[id] = trip;

    state.currentId = id;

    save();


    $('tripName').value = '';

    $('creatorName').value = '';


    renderTrip();

    toast('Trip created 🎉');

}


/* =====================================================
   JOIN TRIP
===================================================== */

function joinTrip() {

    const c =
        $('joinCode')
            .value
            .trim()
            .toUpperCase();

    const name =
        $('joinName')
            .value
            .trim();


    if (c.length !== 6) {

        return toast(
            'Enter a 6-character trip code.'
        );

    }


    if (!name) {

        return toast(
            'Enter your name.'
        );

    }


    const trip =
        Object.values(state.trips)
            .find(t => t.code === c);


    if (!trip) {

        return toast(
            'Trip not found on this device.'
        );

    }


    let m =
        trip.members.find(
            x =>
                x.name.toLowerCase() ===
                name.toLowerCase()
        );


    if (!m) {

        trip.members.push({

            id: uid(),

            name

        });

    }


    state.currentId = trip.id;

    save();

    renderTrip();


    $('joinCode').value = '';

    $('joinName').value = '';


    toast('Joined trip 👥');

}


/* =====================================================
   ADD MEMBER
===================================================== */

function addMember() {

    openModal(
        'Add Friend',
        'Add someone to this trip.',
        `
        <label>Friend Name</label>

        <input
            id="newMemberName"
            placeholder="e.g. Rahul"
            maxlength="40"
        >

        <button
            class="btn btn-primary full"
            id="saveMember"
        >
            Add Friend
        </button>
        `
    );


    $('saveMember').onclick = () => {

        const n =
            $('newMemberName')
                .value
                .trim();


        if (!n) {

            return toast(
                'Enter a name.'
            );

        }


        const t = current();


        if (
            t.members.some(
                m =>
                    m.name.toLowerCase() ===
                    n.toLowerCase()
            )
        ) {

            return toast(
                'That member already exists.'
            );

        }


        t.members.push({

            id: uid(),

            name: n

        });


        save();

        closeModal();

        renderTrip();

        toast('Friend added 👥');

    };

}


/* =====================================================
   EXPENSE FORM
===================================================== */

function expenseForm(exp = null) {

    const t = current();

    if (!t) return;


    const members = t.members;

    const selected =
        exp
            ? exp.splitBetween
            : members.map(m => m.id);


    const mode =
        exp && exp.splitMode === 'custom'
            ? 'custom'
            : 'equal';


    openModal(
        exp ? 'Edit Expense' : 'Add Expense',
        'Choose who paid and who shares the cost.',

        `
        <label>Expense Name</label>

        <input
            id="eName"
            value="${exp ? esc(exp.name) : ''}"
            placeholder="e.g. Hotel, Food, Taxi"
            maxlength="60"
        >


        <label>Amount</label>

        <input
            id="eAmount"
            type="number"
            inputmode="decimal"
            min="0"
            step="0.01"
            value="${exp ? exp.amount : ''}"
            placeholder="0"
        >


        <label>Paid By</label>

        <select id="ePaid">

            ${members.map(m => `

                <option
                    value="${m.id}"
                    ${exp && exp.paidBy === m.id ? 'selected' : ''}
                >
                    ${esc(m.name)}
                </option>

            `).join('')}

        </select>


        <label>Split Type</label>

        <div class="choice-row">

            <button
                type="button"
                class="choice ${mode === 'equal' ? 'selected' : ''}"
                data-mode="equal"
            >
                Equal Split
            </button>

            <button
                type="button"
                class="choice ${mode === 'custom' ? 'selected' : ''}"
                data-mode="custom"
            >
                Custom Split
            </button>

        </div>


        <div id="splitArea"></div>


        <div class="split-total">

            <span>Selected total</span>

            <b id="splitTotal">
                ${money(0)}
            </b>

        </div>


        <button
            class="btn btn-primary full"
            id="saveExpense"
        >
            ${exp ? 'Save Changes' : 'Add Expense'}
        </button>
        `
    );


    let splitMode = mode;

    const area = $('splitArea');


    function draw() {

        document
            .querySelectorAll('.choice')
            .forEach(b =>
                b.classList.toggle(
                    'selected',
                    b.dataset.mode === splitMode
                )
            );


        if (splitMode === 'equal') {

            area.innerHTML = `

                <div class="check-list">

                    ${members.map(m => `

                        <div class="check-item">

                            <input
                                type="checkbox"
                                class="split-check"
                                value="${m.id}"
                                ${selected.includes(m.id) ? 'checked' : ''}
                            >

                            <label>
                                ${esc(m.name)}
                            </label>

                        </div>

                    `).join('')}

                </div>

            `;

        } else {

            area.innerHTML = `

                <div class="check-list">

                    ${members.map(m => `

                        <div class="custom-row">

                            <span>
                                ${esc(m.name)}
                            </span>

                            <input
                                class="custom-amount"
                                data-id="${m.id}"
                                type="number"
                                min="0"
                                step="0.01"
                                placeholder="0"
                                value="${
                                    exp &&
                                    exp.customSplits?.[m.id] != null
                                        ? exp.customSplits[m.id]
                                        : selected.includes(m.id)
                                            ? ''
                                            : ''
                                }"
                            >

                        </div>

                    `).join('')}

                </div>

            `;

        }


        updateTotal();

    }


    function updateTotal() {

        let total = 0;


        if (splitMode === 'equal') {

            const amount =
                Number(
                    $('eAmount').value
                ) || 0;


            const n =
                document
                    .querySelectorAll(
                        '.split-check:checked'
                    )
                    .length;


            total = n
                ? amount
                : 0;


        } else {

            document
                .querySelectorAll(
                    '.custom-amount'
                )
                .forEach(i => {

                    total +=
                        Number(i.value) || 0;

                });

        }


        $('splitTotal').textContent =
            money(total);

    }


    document
        .querySelectorAll('.choice')
        .forEach(b => {

            b.onclick = () => {

                splitMode =
                    b.dataset.mode;

                draw();

            };

        });


    $('eAmount').oninput =
        updateTotal;


    draw();


    $('modalBody').addEventListener(
        'input',
        e => {

            if (
                e.target.classList.contains(
                    'custom-amount'
                )
            ) {

                updateTotal();

            }

        }
    );


    $('modalBody').addEventListener(
        'change',
        e => {

            if (
                e.target.classList.contains(
                    'split-check'
                )
            ) {

                updateTotal();

            }

        }
    );


    $('saveExpense').onclick = () => {

        const name =
            $('eName')
                .value
                .trim();


        const amount =
            Number(
                $('eAmount').value
            );


        const paidBy =
            $('ePaid').value;


        if (!name) {

            return toast(
                'Enter an expense name.'
            );

        }


        if (!(amount > 0)) {

            return toast(
                'Enter a valid amount.'
            );

        }


        let splitBetween = [];

        let customSplits = null;


        if (splitMode === 'equal') {

            splitBetween =
                [
                    ...document
                        .querySelectorAll(
                            '.split-check:checked'
                        )
                ]
                .map(x => x.value);


            if (!splitBetween.length) {

                return toast(
                    'Select at least one person.'
                );

            }


        } else {

            customSplits = {};


            document
                .querySelectorAll(
                    '.custom-amount'
                )
                .forEach(i => {

                    const v =
                        Number(i.value) || 0;


                    if (v > 0) {

                        customSplits[
                            i.dataset.id
                        ] = v;

                        splitBetween.push(
                            i.dataset.id
                        );

                    }

                });


            const total =
                Object.values(
                    customSplits
                )
                .reduce(
                    (a, b) => a + b,
                    0
                );


            if (!splitBetween.length) {

                return toast(
                    'Enter at least one share.'
                );

            }


            if (
                Math.abs(
                    total - amount
                ) > 0.01
            ) {

                return toast(
                    `Custom split must equal ${money(amount)}.`
                );

            }

        }


        const obj = {

            id:
                exp?.id || uid(),

            name,

            amount,

            paidBy,

            splitBetween,

            splitMode,

            customSplits,

            createdAt:
                exp?.createdAt ||
                new Date().toISOString()

        };


        const t = current();


        if (exp) {

            const i =
                t.expenses.findIndex(
                    x => x.id === exp.id
                );

            t.expenses[i] = obj;

        } else {

            t.expenses.push(obj);

        }


        save();

        closeModal();

        renderTrip();


        toast(
            exp
                ? 'Expense updated'
                : 'Expense added 💰'
        );

    };

}


/* =====================================================
   DELETE EXPENSE
===================================================== */

function deleteExpense(id) {

    const t = current();

    const e =
        t.expenses.find(
            x => x.id === id
        );


    if (!e) return;


    if (
        !confirm(
            `Delete "${e.name}"?`
        )
    ) return;


    t.expenses =
        t.expenses.filter(
            x => x.id !== id
        );


    save();

    renderTrip();

    toast('Expense deleted');

}


/* =====================================================
   SHARES
===================================================== */

function shares(exp) {

    if (
        exp.splitMode === 'custom'
    ) {

        return exp.customSplits || {};

    }


    const n =
        exp.splitBetween.length || 1;


    const v =
        exp.amount / n;


    return Object.fromEntries(

        exp.splitBetween.map(
            id => [id, v]
        )

    );

}


/* =====================================================
   BALANCES
===================================================== */

function balances() {

    const t = current();

    const b =
        Object.fromEntries(
            t.members.map(
                m => [m.id, 0]
            )
        );


    t.expenses.forEach(e => {

        b[e.paidBy] =
            (b[e.paidBy] || 0) +
            Number(e.amount);


        const s =
            shares(e);


        Object.entries(s)
            .forEach(([id, v]) => {

                b[id] =
                    (b[id] || 0) -
                    Number(v);

            });

    });


    return b;

}


/* =====================================================
   SETTLEMENT
===================================================== */

function settlements() {

    const b = balances();

    const t = current();


    const creditors =
        t.members

            .map(m => ({
                id: m.id,
                name: m.name,
                b: +b[m.id] || 0
            }))

            .filter(x => x.b > 0.01)

            .sort(
                (a, z) => z.b - a.b
            );


    const debtors =
        t.members

            .map(m => ({
                id: m.id,
                name: m.name,
                b: +b[m.id] || 0
            }))

            .filter(x => x.b < -0.01)

            .sort(
                (a, z) => a.b - z.b
            );


    const out = [];

    let i = 0;
    let j = 0;


    while (
        i < debtors.length &&
        j < creditors.length
    ) {

        const d = debtors[i];

        const c = creditors[j];


        const amt =
            Math.min(
                -d.b,
                c.b
            );


        if (amt > 0.01) {

            out.push({

                from: d,

                to: c,

                amount: amt

            });

        }


        d.b += amt;

        c.b -= amt;


        if (
            Math.abs(d.b) < 0.01
        ) {

            i++;

        }


        if (
            Math.abs(c.b) < 0.01
        ) {

            j++;

        }

    }


    return out;

}


/* =====================================================
   EMPTY STATE
===================================================== */

function empty(
    icon = '📭',
    title = 'Nothing here',
    sub = ''
) {

    return `

        <div class="empty">

            <strong>
                ${icon} ${title}
            </strong>

            ${
                sub
                    ? `<small>${sub}</small>`
                    : ''
            }

        </div>

    `;

}


/* =====================================================
   RENDER RECENT EXPENSES
===================================================== */

function renderRecentExpenses(t) {

    const el =
        $('recentExpensesList');

    if (!el) return;


    if (!t.expenses.length) {

        el.innerHTML =
            empty(
                '💸',
                'No expenses yet',
                'Add your first trip expense.'
            );

        return;

    }


    el.innerHTML =
        t.expenses

            .slice()
            .reverse()

            .slice(0, 3)

            .map(e => {

                const p =
                    t.members.find(
                        m =>
                            m.id === e.paidBy
                    );


                return `

                    <div class="card expense-card">

                        <div>

                            <b>
                                ${esc(e.name)}
                            </b>

                            <small>
                                Paid by
                                ${esc(
                                    p?.name ||
                                    'Unknown'
                                )}
                            </small>

                        </div>


                        <div class="expense-amount">

                            ${money(e.amount)}

                        </div>

                    </div>

                `;

            })

            .join('');

}


/* =====================================================
   RENDER TRIP
===================================================== */

function renderTrip() {

    const t = current();


    if (!t) {

        show('home');

        return;

    }


    /* TRIP HEADER */

    $('tripTitle').textContent =
        t.name;


    $('tripCode').textContent =
        t.code;


    $('tripMemberCount').textContent =
        `${t.members.length} member${
            t.members.length === 1
                ? ''
                : 's'
        }`;


    $('totalMembers').textContent =
        t.members.length;


    const total =
        t.expenses.reduce(
            (s, e) =>
                s + Number(e.amount),
            0
        );


    $('totalExpense').textContent =
        money(total);


    /* RECENT EXPENSES */

    renderRecentExpenses(t);


    /* MEMBERS */

    $('membersList').innerHTML =

        t.members.length

            ? t.members

                .map((m, i) => `

                    <div class="card member-card">

                        <div class="avatar">

                            ${esc(
                                m.name[0]
                                    ?.toUpperCase() ||
                                '?'
                            )}

                        </div>


                        <div>

                            <b>
                                ${esc(m.name)}
                            </b>

                            <small>
                                ${
                                    i === 0
                                        ? 'Trip creator'
                                        : 'Trip member'
                                }
                            </small>

                        </div>

                    </div>

                `)

                .join('')

            : empty(
                '👥',
                'No members yet'
            );


    /* EXPENSES */

    $('expensesList').innerHTML =

        t.expenses.length

            ? t.expenses

                .slice()
                .reverse()

                .map(e => {

                    const p =
                        t.members.find(
                            m =>
                                m.id ===
                                e.paidBy
                        );


                    const s =
                        shares(e);


                    const n =
                        Object.keys(s)
                            .length;


                    return `

                        <div class="card expense-card">

                            <div>

                                <b>
                                    ${esc(e.name)}
                                </b>

                                <small>
                                    Paid by
                                    ${esc(
                                        p?.name ||
                                        'Unknown'
                                    )}
                                    · Split between
                                    ${n}
                                </small>


                                <div class="card-actions">

                                    <button
                                        class="mini-btn"
                                        data-edit="${e.id}"
                                    >
                                        Edit
                                    </button>


                                    <button
                                        class="mini-btn"
                                        data-delete="${e.id}"
                                    >
                                        Delete
                                    </button>

                                </div>

                            </div>


                            <div class="expense-amount">

                                ${money(e.amount)}

                            </div>

                        </div>

                    `;

                })

                .join('')

            : empty(
                '💸',
                'No expenses yet',
                'Add your first trip expense.'
            );


    /* BALANCES */

    const b = balances();


    $('balancesList').innerHTML =

        t.members

            .map(m => {

                const v =
                    b[m.id] || 0;


                const cls =
                    v > 0.01
                        ? 'positive'
                        : v < -0.01
                            ? 'negative'
                            : '';


                const text =
                    v > 0.01
                        ? `Gets ${money(v)}`
                        : v < -0.01
                            ? `Owes ${money(-v)}`
                            : 'Settled';


                return `

                    <div class="card balance-card">

                        <div>

                            <b>
                                ${esc(m.name)}
                            </b>

                            <small>
                                ${text}
                            </small>

                        </div>


                        <strong class="${cls}">

                            ${
                                v > 0.01
                                    ? '+'
                                    : v < -0.01
                                        ? '-'
                                        : ''
                            }

                            ${money(
                                Math.abs(v)
                            )}

                        </strong>

                    </div>

                `;

            })

            .join('');


    /* SETTLEMENT */

    const st = settlements();


    $('settlementList').innerHTML =

        st.length

            ? st

                .map(x => `

                    <div class="settlement-card">

                        <div class="who">

                            <b>
                                ${esc(x.from.name)}
                            </b>

                            <small>
                                pays
                            </small>

                        </div>


                        <div class="settle-arrow">
                            →
                        </div>


                        <div class="who">

                            <b>
                                ${esc(x.to.name)}
                            </b>

                            <small>
                                receives
                            </small>

                        </div>


                        <div class="settle-money">

                            ${money(x.amount)}

                        </div>

                    </div>

                `)

                .join('')

            : empty(
                '🤝',
                'All settled',
                'No payments are pending.'
            );


    show('trip');

}


/* =====================================================
   SHARE TRIP
===================================================== */

async function share() {

    const t = current();

    if (!t) return;


    const text =
        `Join my TripSplit trip!\n` +
        `Trip: ${t.name}\n` +
        `Code: ${t.code}`;


    if (navigator.share) {

        try {

            await navigator.share({

                title: 'Join TripSplit',

                text

            });

        } catch {}

    } else {

        try {

            await navigator.clipboard.writeText(
                text
            );

            toast(
                'Invite copied 📋'
            );

        } catch {

            toast(
                `Code: ${t.code}`
            );

        }

    }

}


/* =====================================================
   EVENT LISTENERS
===================================================== */


/* HOME */

$('createTripBtn')?.addEventListener(
    'click',
    () => show('create')
);


$('joinTripBtn')?.addEventListener(
    'click',
    () => show('join')
);


/* CREATE */

$('createConfirmBtn')?.addEventListener(
    'click',
    createTrip
);


/* JOIN */

$('joinConfirmBtn')?.addEventListener(
    'click',
    joinTrip
);


/* MEMBERS */

$('addMemberBtn')?.addEventListener(
    'click',
    addMember
);


/* EXPENSES */

$('addExpenseBtn')?.addEventListener(
    'click',
    () => expenseForm()
);


/* MODAL */

$('closeModal')?.addEventListener(
    'click',
    closeModal
);


$('modal')?.addEventListener(
    'click',
    e => {

        if (
            e.target === $('modal')
        ) {

            closeModal();

        }

    }
);


/* HEADER */

$('homeBtn')?.addEventListener(
    'click',
    () => show('home')
);


$('backBtn')?.addEventListener(
    'click',
    () => show('home')
);


/* COPY CODE */

$('copyCodeBtn')?.addEventListener(
    'click',
    async () => {

        const t = current();

        if (!t) return;


        try {

            await navigator.clipboard.writeText(
                t.code
            );

            toast(
                'Trip code copied 📋'
            );

        } catch {

            toast(
                `Code: ${t.code}`
            );

        }

    }
);


/* SHARE */

$('shareBtn')?.addEventListener(
    'click',
    share
);


/* EXPENSE EDIT / DELETE */

$('expensesList')?.addEventListener(
    'click',
    e => {

        const edit =
            e.target.dataset.edit;

        const del =
            e.target.dataset.delete;


        if (edit) {

            const ex =
                current()
                    ?.expenses
                    .find(
                        x => x.id === edit
                    );


            if (ex) {

                expenseForm(ex);

            }

        }


        if (del) {

            deleteExpense(del);

        }

    }
);


/* =====================================================
   BOTTOM NAV EVENTS
===================================================== */

document
    .querySelectorAll('.nav-item')
    .forEach(btn => {

        btn.addEventListener(
            'click',
            () => {

                openTab(
                    btn.dataset.tab
                );

            }
        );

    });


/* =====================================================
   OVERVIEW QUICK ACTIONS
===================================================== */

$('overviewAddExpense')?.addEventListener(
    'click',
    () => expenseForm()
);


$('overviewAddMember')?.addEventListener(
    'click',
    () => addMember()
);


/* =====================================================
   VIEW ALL BUTTONS
===================================================== */

document
    .querySelectorAll('[data-tab]')
    .forEach(btn => {

        if (
            btn.classList.contains(
                'nav-item'
            )
        ) return;


        btn.addEventListener(
            'click',
            () => {

                openTab(
                    btn.dataset.tab
                );

            }
        );

    });


/* =====================================================
   INITIALIZE
===================================================== */

load();


if (current()) {

    renderTrip();

}